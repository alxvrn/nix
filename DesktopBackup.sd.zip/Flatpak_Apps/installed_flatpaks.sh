flatpak install --system org.fedoraproject.MediaWriter -y
flatpak install --system io.gitlab.adhami3310.Converter -y
flatpak install --system io.github.swordpuffin.rewaita -y
flatpak install --system io.github.vikdevelop.SaveDesktop -y
